import { RiMenu2Fill } from "react-icons/ri";
import './Navbar.css';

function Navbar() {
  return (
    <div>
        <div className="navbar" >
            <RiMenu2Fill className="text-[25px]"/>
            
            
        </div>
    </div>
  )
}

export default Navbar